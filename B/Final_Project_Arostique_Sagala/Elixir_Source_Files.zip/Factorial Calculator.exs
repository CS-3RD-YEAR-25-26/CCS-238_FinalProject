# Factorial Calculator

defmodule Factorial do
  # The literal clause matches the base case and stops at 0! = 1.
  def calculate(0), do: 1

  # The guard accepts positive integers. Each call uses the preceding integer.
  def calculate(n) when is_integer(n) and n > 0 do
    n * calculate(n - 1)
  end
end

# Change n here to try a different nonnegative integer.
n = 5
IO.puts("Factorial of #{n}: #{Factorial.calculate(n)}")
