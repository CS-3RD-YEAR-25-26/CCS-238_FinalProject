# Shopping Cart Calculator

# Each product is listed as [name, quantity, unit_price].
products = [
  ["Pencil", 3, 10],
  ["Notebook", 2, 50]
]

defmodule ShoppingCartCalculator do
  # Apply this percentage when the subtotal reaches the minimum.
  @discount_rate 10
  @discount_minimum 100

  def calculate_cart(products) do
    print_row("Product", "Qty", "Price", "Item Total")

    # Print each row and return the updated subtotal for the next product.
    subtotal =
      Enum.reduce(products, 0, fn [name, quantity, unit_price], running_subtotal ->
        item_total = quantity * unit_price
        print_row(name, quantity, unit_price, item_total)
        running_subtotal + item_total
      end)

    IO.puts("\nSubtotal: #{format_amount(subtotal)}")

    # Integer.floor_div rounds the percentage discount down to a whole unit.
    discount =
      if subtotal >= @discount_minimum do
        Integer.floor_div(subtotal * @discount_rate, 100)
      else
        0
      end

    IO.puts("Discount (#{@discount_rate}%): #{format_amount(discount)}")
    IO.puts("Final total: #{format_amount(subtotal - discount)}")
  end

  # Pad each column to the same minimum width as the Lisp table.
  defp print_row(name, quantity, unit_price, item_total) do
    [
      String.pad_trailing(to_string(name), 12),
      String.pad_trailing(to_string(quantity), 5),
      String.pad_trailing(to_string(unit_price), 7),
      String.pad_trailing(to_string(item_total), 10)
    ]
    |> Enum.join(" ")
    |> IO.puts()
  end

  # Keep table entries as integers and display summary amounts to two decimals.
  defp format_amount(amount) do
    :erlang.float_to_binary(amount / 1, decimals: 2)
  end
end

# Run the calculator on the sample products.
ShoppingCartCalculator.calculate_cart(products)
