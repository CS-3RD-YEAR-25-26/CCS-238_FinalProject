# Student Grade Analyzer

grades = [85, 92, 70, 58]

defmodule StudentGradeAnalyzer do
  @passing_score 70

  def analyze_grades(grades) do
    # Check for an empty list before calculating the average or extrema.
    if grades == [] do
      IO.puts("No grades available.")
    else
      # Join the scores with spaces to match the Lisp list display.
      IO.puts("Grades: (#{Enum.join(grades, " ")})")

      # Sum the grades and format the average to two decimals.
      average = Enum.sum(grades) / length(grades)
      IO.puts("Average: #{:erlang.float_to_binary(average, decimals: 2)}")

      IO.puts("Highest: #{Enum.max(grades)}")
      IO.puts("Lowest: #{Enum.min(grades)}")

      # Carry both counts in a tuple. A grade equal to the cutoff passes.
      {passing_count, failing_count} =
        Enum.reduce(grades, {0, 0}, fn grade, {passing, failing} ->
          if grade >= @passing_score do
            {passing + 1, failing}
          else
            {passing, failing + 1}
          end
        end)

      IO.puts("Passing grades: #{passing_count}")
      IO.puts("Failing grades: #{failing_count}")
      IO.puts("Passing threshold: #{@passing_score}")
    end
  end
end

# Run the analyzer on the sample grades.
StudentGradeAnalyzer.analyze_grades(grades)
