
;; Student Grade Analyzer

;; The ' prevents Lisp from evaluating the list.
;; You can modify the grades list '(n) to be analyzed in the function analyze-grades
(defparameter *grades* '(85 92 70 58))
(defparameter *passing-score* 70)

;; DEFUN defines a function that accepts a list.
(defun analyze-grades (grades)

  ;; NULL checks whether the list is empty.
  ;; IF selects one of two expressions.
  (if (null grades)
      (format t "No grades available.~%")

      ;; PROGN allows multiple expressions inside a single IF branch.
      (progn
        (format t "Grades: ~A~%" grades)

        ;; REDUCE combines list elements using +, #' refers to the addition function.
        (format t "Average: ~,2F~%"
                (/ (reduce #'+ grades) (float (length grades)))
        )

        ;; APPLY passes list elements as arguments
        (format t "Highest: ~A~%"
                (apply #'max grades))

        (format t "Lowest: ~A~%"
                (apply #'min grades))

        ;; Count passing and failing grades using DOLIST, IF, and counters.

        ;; LET initializes both counters to zero.
        (let ((passing-count 0)
              (failing-count 0))

          ;; DOLIST iterates through each grade in the list.
          (dolist (grade grades)

            ;; IF checks whether the grade meets the passing threshold.
            (if (>= grade *passing-score*)

                ;; INCF increments the passing counter by 1 if true.
                (incf passing-count)

                ;; INCF increments the failing counter by 1 if false.
                (incf failing-count)
            )
          )

          ;; Display the total passing and failing grades.
          (format t "Passing grades: ~A~%" passing-count)
          (format t "Failing grades: ~A~%" failing-count)
        )

        (format t "Passing threshold: ~A~%" *passing-score*)
      )
  )
)

;; Call the function using our grade list.
(analyze-grades *grades*)
