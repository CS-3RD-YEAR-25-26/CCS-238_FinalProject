;;; Factorial Calculator

;; Calculate the factorial of a nonnegative integer.
(defun factorial (n)
  (if (= n 0)
      ;; The base case stops the recursion at 0! = 1.
      1
      ;; Multiply n by the result for the preceding integer.
      (* n (factorial (- n 1)))))

;; Change n here to try a different nonnegative integer.
(let ((n 5))
  (format t "Factorial of ~A: ~A~%" n (factorial n)))
