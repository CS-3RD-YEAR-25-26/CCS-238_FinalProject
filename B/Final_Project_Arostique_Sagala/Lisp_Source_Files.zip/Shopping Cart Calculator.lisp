
    ;;; Shopping Cart Calculator

    ;; The ' prevents Lisp from evaluating the list.
    ;; Each nested list contains: (Name Quantity Price).
    (defparameter *products*
    '(("Pencil" 3 10)
        ("Notebook" 2 50)
    )
    )

    ;; These variables control the discount rules.
    (defparameter *discount-rate* 10)
    (defparameter *discount-minimum* 100)

    ;; DEFUN defines a function that accepts a list.
    (defun calculate-cart (products)

    ;; LET creates a local variable for the subtotal.
    (let ((subtotal 0))

        ;; FORMAT displays a table.
        (format t "~12A ~5A ~7A ~10A~%"
                "Product" "Qty" "Price" "Item Total")

        ;; DOLIST iterates through each product in the list.
        (dolist (product products)

            ;; LET creates a local binding for each item total.
            ;; FIRST retrieves the product name.
            ;; SECOND retrieves the quantity.
            ;; THIRD retrieves the price.
            (let ((item-total
                (* (second product) (third product))))

                (format t "~12A ~5A ~7A ~10A~%"
                    (first product)
                    (second product)
                    (third product)
                    item-total)

                ;; INCF increases the subtotal by item-total.
                (incf subtotal item-total)))

            ;; FLOAT converts the integer subtotal to a float.
            (format t "~%Subtotal: ~,2F~%" (float subtotal))

            ;; LET creates a local variable for the discount.
            ;; IF checks whether the subtotal meets the minimum.
            ;; >= compares two numerical values.
            (let ((discount
                    (if (>= subtotal *discount-minimum*)
                        (floor (* subtotal *discount-rate*) 100)
                        0)
                    )
                )

            ;; Display the discount amount.
            (format t "Discount (~A%): ~,2F~%"
                *discount-rate*
                (float discount))

            ;; Subtract the discount from the subtotal.
            ;; Lisp uses prefix notation for subtraction.
            (format t "Final total: ~,2F~%" (float (- subtotal discount)))
        )
    )
    )

    ;; Call the function with the product list.
    (calculate-cart *products*)
